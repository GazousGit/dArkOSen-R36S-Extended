#!/bin/bash

if [ "$(id -u)" -ne 0 ]; then
    exec sudo -- "$0" "$@"
fi

UPDATE_DATE="10162026-playdate"
LOG_FILE="/home/ark/dArkOSen-update$UPDATE_DATE.log"
UPDATE_DONE="/home/ark/.config/.dArkOSen-update$UPDATE_DATE"

exec > >(tee -a "$LOG_FILE") 2>&1
set -x

printf "Running update script" >> "$LOG_FILE" 2>&1

if [ -f "/opt/system/Tools/10162026-playdate.zip" ]; then
	# installs
	unzip -X -o /opt/system/Tools/10162026-playdate.zip -d / | tee -a "$LOG_FILE"
	sleep 1

	# permissions
	chmod +x "/usr/local/bin/night_filter.sh"
	chmod +x "/usr/local/bin/speak_bat_life.sh"
	chmod +x "/usr/local/bin/playtimer_watchdog.sh"
	chmod +x "/usr/local/bin/batt_life_verbal_warning.py"
	chmod +x "/usr/local/bin/perfmax"
	chmod +x "/usr/bin/emulationstation/emulationstation"

	chown ark:ark "/usr/local/bin/night_filter.sh"
	chown ark:ark "/usr/local/bin/speak_bat_life.sh"
	chown ark:ark "/usr/local/bin/playtimer_watchdog.sh"
	chown ark:ark "/usr/local/bin/batt_life_verbal_warning.py"
	chown ark:ark "/usr/local/bin/perfmax"
	chown ark:ark "/usr/bin/emulationstation/emulationstation"

	systemctl daemon-reload
	systemctl enable --now night-filter.timer

	# copy ES
	cp -f "/usr/bin/emulationstation/emulationstation" "/usr/bin/emulationstation/emulationstation.darkosen"

	# fix verbal bat warning
	mkdir -p /usr/local/bin/.asoundbackup
	cp /home/ark/.asoundrcbak /usr/local/bin/.asoundbackup/.asoundrcbak.rk3326
	sed -i 's|<string name="VerbalBatteryWarning" value="yes" />|<string name="VerbalBatteryWarning" value="no" />|' /home/ark/.emulationstation/es_settings.cfg
	touch /home/ark/.config/.NOVERBALBATTERYWARNING
else
	printf "Could not find 10162026-playdate.zip" >> "$LOG_FILE" 2>&1
	sleep 3
	exit 1
fi

printf "Update script finished." >> "$LOG_FILE" 2>&1
touch "$UPDATE_DONE"
printf "\nUpdate successful" >> "$LOG_FILE" 2>&1

printf "\nUpdate boot text to reflect current version of dArkOSen\n" | tee -a "$LOG_FILE"
sed -i "/title\=/c\title\=dArkOSen ($UPDATE_DATE)" /usr/share/plymouth/themes/text.plymouth
echo "$UPDATE_DATE" > /home/ark/.config/.VERSION

rm -f /opt/system/Tools/10162026-playdate.zip
rm -f "$0"

sleep 2